export const tamanhos = {
    pequeno: 10,
    descricao: 16,
    medio: 24,
    grande: 42,
    altura: 180,
    gigante: 210,
    largura: 290,
};
