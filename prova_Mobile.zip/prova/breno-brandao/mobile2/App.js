import * as React from 'react';
import Route from "./src/components/screens/Route";

export default function App() {
  return (
      <Route/>
  );
}

